# ---- Simulate data and estimate Q using estimator_space ----

# Source your estimator_space definition
library(pcglassoFast)
library(space)
source("article/estimation_methods.R")  # Make sure estimator_space is in this file


data(Q_simulated_glasso)
Q_true <- Q_simulated_glasso
# Simulate n samples from N(0, Q_true^{-1})
library(MASS)
set.seed(2025)
n <- 1500
Sigma_true <- solve(Q_true)
p <- dim(Q_true)[1]
X <- MASS::mvrnorm(n = n, mu = rep(0, p), Sigma = Sigma_true)

# 1) Decide on a train/test split ratio
set.seed(123)             # for reproducibility
n_total <- nrow(X)
train_frac <- 0.7         # 70% training, 30% test

# 2) Sample row‐indices for the training set
n_train <- floor(train_frac * n_total)
train_idx <- sample(seq_len(n_total), size = n_train, replace = FALSE)

# 3) Create train/test subsets of X
X_train <- X[train_idx, , drop = FALSE]
X_test  <- X[-train_idx, , drop = FALSE]

# 4) Compute covariance matrices on each subset
S_full  <- cov(X)        # covariance on the full data (if you want to use all data for BIC, etc.)
S_train <- cov(X_train)  # covariance for training
S_test  <- cov(X_test)   # covariance for testing (held‐out)

# 5) Record sample sizes
n_train <- nrow(X_train)
n_test  <- nrow(X_test)
n       <- n_total       # if the function needs the full sample size

# 6) Call estimator_space with these pieces
result <- estimator_space(
  S_full   = S_full,      # (optionally) covariance on all n rows
  S_train  = S_train,     # covariance on the training set only
  S_test   = S_test,      # covariance on the test set only
  n        = n,
  n_train  = n_train,
  n_test   = n_test,
  lambdas  = exp(seq(log(2), log(0.8), length.out = 10)),
  data     = X,          # full data (if needed internally)
  train    = X_train,    # pass only the training rows here
  test     = X_test      # pass only the test rows here
)
# Print estimated precision matrix (BIC selection)
cat("True Q:\n")
print(sum(Q_true!=0))

cat("\nEstimated Q (SPACE, BIC selection):\n")
print(sum(result$Space_bic$Q!=0))

cat("\nEstimated Q (SPACE, CV selection):\n")
print(sum(result$Space_cv$Q!=0))
